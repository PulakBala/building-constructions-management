<?php 
  include('connection.php');
  include('header.php');
  include('sidebar.php');

  if (isset($_GET['name'])) {
      $building_name = htmlspecialchars($_GET['name']); // Get the building name from the URL
  } else {
      $building_name = ''; // Default value if name is not set
  }
?>

<main class="page-content">
  <div class="container-fluid">
    <div class="row">
      <section class="container my-4">

        <div class="row justify-content-end mb-4">
          <div class="col-md-6">
            <!-- Search Input with Bootstrap Design -->
            <div class="input-group">
              <input type="text" id="searchInput" class="form-control" placeholder="Search Flat Owner...">
              <div class="input-group-append">
                <span class="input-group-text"><i class="fas fa-search"></i></span>
              </div>
            </div>
          </div>
        </div>

        <!-- Search Results will appear here -->
        <div id="searchResults" class="my-4"></div>

        <div class="card-container">
          <?php
          // Fetch data based on the building_name
          $sqlSelect = "SELECT id, bulding_name, name, mobile_number, nid_number, nid_img, rent, advance, created_at 
                        FROM flat_info 
                        WHERE bulding_name = ?";
          $stmt = $conn->prepare($sqlSelect);
          $stmt->bind_param("s", $building_name);
          $stmt->execute();
          $result = $stmt->get_result();

          if ($result->num_rows > 0) {
              while ($data = $result->fetch_assoc()) {
          ?>
                  <div class="card">
                    <div class="card-body p-4 shadow-lg rounded" style="background-color: #f8f9fa;">
                      <h5 class="card-title">
                        <span class="fw-bold" style="color: #3498db;">Name:</span>
                        <span class="text-muted"><?php echo $data["name"]; ?></span>
                      </h5>
                      <hr>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #e74c3c;">Rent:</span>
                        <span class="text-muted"><?php echo $data["rent"]; ?></span>
                      </p>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #e74c3c;">Advance:</span>
                        <span class="text-muted"><?php echo $data["advance"]; ?></span>
                      </p>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #2ecc71;">Mobile Number:</span>
                        <span class="text-muted"><?php echo $data["mobile_number"]; ?></span>
                      </p>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #e67e22;">NID Number:</span>
                        <span class="text-muted"><?php echo $data["nid_number"]; ?></span>
                      </p>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #e67e22;">NID Image:</span>
                        <span class="text-muted"><a href="<?php echo $data["nid_img"]; ?>" target="_blank">View Image</a></span>
                      </p>

                      <p class="card-text">
                        <span class="fw-bold" style="color: #e67e22;">Date:</span>
                        <span class="text-muted"><?php echo $data["created_at"]; ?></span>
                      </p>
                      <!-- edit and delete button  -->
                      <a href="edit-flat.php?id=<?php echo $data['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                      <a href="delete_flat_info.php?id=<?php echo $data['id']; ?>" class="btn btn-info btn-sm">Delete</a>
                    </div>
                  </div>
          <?php
              }
          } else {
              echo "<p class='text-center text-muted'>No data found for the selected building!</p>";
          }
          ?>
        </div>
      </section>
    </div>
  </div>
</main>

<?php include('footer.php'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    $('#searchInput').on('keyup', function() {
      var searchQuery = $(this).val();

      if (searchQuery !== '') {
        $.ajax({
          url: 'search_all_flat.php',
          method: 'POST',
          data: {
            query: searchQuery
          },
          success: function(response) {
            $('#searchResults').html(response);
          }
        });
      } else {
        $('#searchResults').html(''); // Clear the results when the search field is empty
      }
    });
  });
</script>
