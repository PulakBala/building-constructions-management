<?php include('connection.php') ?>
<?php 

$_SESSION['sa_crm_drs_id'] = false;	
header("Location: login.php");

?>
