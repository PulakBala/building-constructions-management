<?php include('header.php') ?>
<?php include('sidebar.php') ?>


<main class="page-content">

  <div class="container-fluid">

    <div class="row">




    </div>

  </div>
</main>
<?php include('footer.php') ?> 


jodi hater dane jaye taile left => U R U R' U'
jodi hater bame jaye taile right =>L' U' L U